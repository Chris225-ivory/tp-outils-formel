import java.util.Scanner;
import java.util.HashSet;

class ControlAccessAutomate1 {

    private static final String CODE_DEFAULT = "MIAGE2025";
    private static final int MAX_TENTATIVES = 5;
    private int tentatives;
    private final HashSet<String> cartesValides;

    public ControlAccessAutomate1() {
        tentatives = 0;
        cartesValides = new HashSet<>();
        cartesValides.add("1234");
        cartesValides.add("5678");
    }


    public String verifierAcces(String carteSaisie, String codeSaisi) {
        boolean carteValide = cartesValides.contains(carteSaisie);
        boolean codeCorrect = CODE_DEFAULT.equals(codeSaisi);

        if (carteValide && codeCorrect) {
            tentatives = 0;
            return "Accès accordé";
        } else if (!carteValide) {
            return "Accès refusé";
        } else {
            tentatives++;
            if (tentatives >= MAX_TENTATIVES) {
                tentatives = 0;
                return "Alarme déclenchée";
            } else {
                return "Code incorrect, tentatives restantes : " + (MAX_TENTATIVES - tentatives);
            }
        }
    }

}


public class ControlAccessAutomate1Test {

    public static void main(String[] args) {
        ControlAccessAutomate1 system = new ControlAccessAutomate1();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Entrez l'identifiant de la carte : ");
            String carteSaisie = scanner.nextLine();

            System.out.print("Entrez le code d'accès : ");
            String codeSaisi = scanner.nextLine();

            String resultat = system.verifierAcces(carteSaisie, codeSaisi);
            System.out.println(resultat);

            if (resultat.equals("Accès refusé") || resultat.equals("Alarme déclenchée")) {
                break;
            }
        }

        scanner.close();
    }
}
