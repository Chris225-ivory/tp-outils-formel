import java.util.Scanner;
import java.util.HashSet;

public class ControlAccessAutomate {

    private enum Etat {
        VERIFICATION_CARTE, VERIFICATION_CODE, ACCES_ACCORDE, ACCES_REFUSE, ALARME
    }

    private static final String CODE_DEFAULT = "MIAGE2025"; 
    private static final int MAX_TENTATIVES = 5;  
    private int tentatives;  
    private Etat etatCourant;  
    private final HashSet<String> cartesValides;

    public ControlAccessAutomate() {
        tentatives = 0;
        etatCourant = Etat.VERIFICATION_CARTE;  
        cartesValides = new HashSet<>();  
        cartesValides.add("1234");  
        cartesValides.add("5678");  
    }

    
    public static void main(String[] args) {
        ControlAccessAutomate system = new ControlAccessAutomate();
        system.demarrerSysteme();
    }

  
    public void demarrerSysteme() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            switch (etatCourant) {
                case VERIFICATION_CARTE -> {
                    System.out.print("Entrez l'identifiant de la carte : ");
                    String carteSaisie = scanner.nextLine();
                    verifierCarte(carteSaisie);
                }
                case VERIFICATION_CODE -> {
                    System.out.print("Entrez le code d'accès : ");
                    String codeSaisi = scanner.nextLine();
                    verifierCode(codeSaisi);
                }
                case ACCES_ACCORDE -> {
                    System.out.println("Accès déjà accordé. Vous ne pouvez plus entrer de code.");
                    return;
                }
                case ACCES_REFUSE -> {
                    System.out.println("Accès refusé. Veuillez réessayer.");
                    etatCourant = Etat.VERIFICATION_CARTE;
                }
                case ALARME -> {
                    System.out.println("Alarme déclenchée. Le système est verrouillé.");
                    return;
                }
                default -> {
                }
            }
        }


    }

    
    public void verifierCarte(String carteSaisie) {
        if (cartesValides.contains(carteSaisie)) {
            etatCourant = Etat.VERIFICATION_CODE;
        } else {
            etatCourant = Etat.ACCES_REFUSE;
            System.out.println("Carte invalide. Accès refusé.");
        }
    }

    
    public void verifierCode(String codeSaisi) {
        if (CODE_DEFAULT.equals(codeSaisi)) {
            etatCourant = Etat.ACCES_ACCORDE;
            System.out.println("Accès accordé");
        } else {
            tentatives++;
            if (tentatives >= MAX_TENTATIVES) {
                etatCourant = Etat.ALARME;
                System.out.println("Alarme déclenchée après 5 tentatives incorrectes.");
            } else {
                System.out.println("Code incorrect, tentatives restantes : " + (MAX_TENTATIVES - tentatives));
                etatCourant = Etat.VERIFICATION_CODE;
            }
        }
    }
}
