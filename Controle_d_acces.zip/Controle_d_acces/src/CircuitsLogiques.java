import java.util.Scanner;
import java.util.HashSet;

public class CircuitsLogiques {

    private static final String CODE_DEFAULT = "MIAGE2025";
    private static final int MAX_TENTATIVES = 3;
    private int tentatives;

    private final HashSet<String> cartesValides;

    public CircuitsLogiques() {
        tentatives = 0;
        cartesValides = new HashSet<>();
        cartesValides.add("1234");
        cartesValides.add("5678");
    }

    public static void main(String[] args) {
        CircuitsLogiques circuits = new CircuitsLogiques();
        circuits.demarrerSysteme();
    }

    public void demarrerSysteme() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Entrez l'identifiant de la carte : ");
            String carteSaisie = scanner.nextLine();

            System.out.print("Entrez le code d'accès : ");
            String codeSaisi = scanner.nextLine();

            if (!verifierAcces(carteSaisie, codeSaisi)) {
                break;
            }
        }
        scanner.close();
    }

    public boolean verifierAcces(String carteSaisie, String codeSaisi) {
        boolean carteValide = cartesValides.contains(carteSaisie);
        boolean codeCorrect = CODE_DEFAULT.equals(codeSaisi);


        if (carteValide && codeCorrect) {
            System.out.println("Accès accordé");
            tentatives = 0;
            return true;
        } else if (!carteValide) {
            System.out.println("Accès refusé");
            return false;
        } else {
            tentatives++;
            if (tentatives >= MAX_TENTATIVES) {
                System.out.println("Alarme déclenchée après 5 tentatives incorrectes");
                tentatives = 0;
                return false;
            } else {
                System.out.println("Code incorrect, tentatives restantes : " + (MAX_TENTATIVES - tentatives));
                return true;
            }
        }
    }
}
