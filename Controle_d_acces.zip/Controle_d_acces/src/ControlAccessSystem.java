import java.util.Scanner;

public class ControlAccessSystem {

    private static final String CODE_DEFAULT = "MIAGE2025";
    private static final int MAX_TENTATIVES = 5;
    private int tentatives;
    private boolean systemeVerrouille;
    private boolean accesAccorde;
    private final boolean carteValide;

    public ControlAccessSystem() {
        tentatives = 0;
        systemeVerrouille = false;
        accesAccorde = false;
        carteValide = true;
    }


    public static void main(String[] args) {
        ControlAccessSystem system = new ControlAccessSystem();
        system.demarrerSysteme();
    }


    public void demarrerSysteme() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            if (systemeVerrouille) {
                System.out.println("Le système est verrouillé. Vous ne pouvez plus entrer de code.");
                break;
            }

            if (accesAccorde) {
                System.out.println("Accès déjà accordé. Vous ne pouvez plus entrer de code.");
                break;
            }

            System.out.print("Entrez le code d'accès : ");
            String codeSaisi = scanner.nextLine();
            verifierAcces(carteValide, codeSaisi);
        }

        scanner.close();
    }


    public void verifierAcces(boolean carteValide, String codeSaisi) {
        if (carteValide && CODE_DEFAULT.equals(codeSaisi)) {
            System.out.println("Accès accordé");
            accesAccorde = true;
            tentatives = 0;
        } else if (!carteValide) {
            System.out.println("Accès refusé");
        } else {
            tentatives++;
            if (tentatives >= MAX_TENTATIVES) {
                System.out.println("Alarme déclenchée après 5 tentatives incorrectes. Le système est maintenant verrouillé.");
                systemeVerrouille = true;
            } else {
                System.out.println("Code incorrect, tentatives restantes : " + (MAX_TENTATIVES - tentatives));
            }
        }
    }
}
